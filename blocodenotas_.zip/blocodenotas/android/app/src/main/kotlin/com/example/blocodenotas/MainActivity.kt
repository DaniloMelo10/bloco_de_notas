package com.example.blocodenotas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
